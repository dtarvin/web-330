setTimeout(function() {
  $('.content').fadeIn(1000);
}, 5000);

